// ------------------------------------------------------------------
// Firebase konfiguratsiyasi
// ------------------------------------------------------------------
// Quyidagi qiymatlarni O'ZINGIZNING Firebase loyihangizdan oling:
// Firebase Console -> Project settings -> General -> Your apps -> SDK setup and configuration
//
// Eslatma: Authentication bo'limida "Email/Password" provayderini
// yoqishni unutmang (Firebase Console -> Authentication -> Sign-in method).
// ------------------------------------------------------------------
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyCHXq9SPXT80kWtwKYbIfEtzw3QStWnNPo",
  authDomain: "auth-d394d.firebaseapp.com",
  projectId: "auth-d394d",
  storageBucket: "auth-d394d.firebasestorage.app",
  messagingSenderId: "818475600711",
  appId: "1:818475600711:web:c92b40c4f15d44db175a62",
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db = getFirestore(app);
export default app;
